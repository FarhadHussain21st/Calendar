(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	
	
	$(document).ready(function() {
		var ajaxUrl = ajaxurl;
		var calendar = $('#calendar').fullCalendar({
		 editable:true,
		 header:{
		  left:'prev,next today',
		  center:'title',
		  right:'month,agendaWeek,agendaDay'
		 },
		 events: ajaxUrl+'?action=load_data',
		 selectable:true,
		 selectHelper:true,
		 editable:true,
		//  select: function(start, end, allDay) {
		// 	//  end = end.subtract(1, "days");
		// 	 $('#customPopup').show();
		// 	 var formattedDate_start = start.format('DD MMM YYYY');
		// 	 var formattedDate_end = end.format('DD MMM YYYY');
		// 	 if(formattedDate_start !== formattedDate_end ){
		// 		formattedDate_end = end.subtract(1, "days");
		// 		formattedDate_end = end.format('DD MMM YYYY');
		// 	 }else{
		// 		formattedDate_end = formattedDate_start;
		// 	 }

		// 	 $('#cal-data').text(formattedDate_start + ' - ' + formattedDate_end);

		// 	 $('#start_time').val(start.format("hh:mm A"));
    	// 	 $('#end_time').val(end.format("hh:mm A"));

		// 	 $('#eventTitle').val('');
		// 	 $('#saveEvent').off('click').on('click', function() {
		// 		 var title = $('#eventTitle').val();
		// 		 if (title) {
		// 			var startTime = $('#start_time').val();
		// 			var endTime = $('#end_time').val();
					
		// 			var startDate = moment(formattedDate_start + ' ' + startTime, 'DD MMM YYYY hh:mm A');
		// 			var endDate = moment(formattedDate_end + ' ' + endTime, 'DD MMM YYYY hh:mm A');
					
		// 			var formattedStart = startDate.format("Y-MM-DD HH:mm:ss");
		// 			var formattedEnd = endDate.format("Y-MM-DD HH:mm:ss");
		// 			var action = "add_data";
		// 			 $.ajax({
		// 				 url: ajaxUrl,
		// 				 type: "POST",
		// 				 data: { action: action, title: title, start: formattedStart, end: formattedEnd },
		// 				 success: function(response) {
		// 					 calendar.fullCalendar('refetchEvents');
		// 					 $('#customPopup').hide();
		// 				 }
		// 			 });
		// 		 }
		// 	 });
		// },
		select: function(start, end, allDay) {
			$('#customPopup').show();
			end.subtract(1, "days");
			var formattedDate_start = start.format('DD MMM YYYY');
			var formattedDate_end = end.format('DD MMM YYYY');
			
			// Calculate the number of days in the range
			var daysInRange = end.diff(start, 'days') + 1; // Add 1 to include the start date
		
			// Create an array to store the individual dates
			var dateArray = [];
		
			for (var i = 0; i < daysInRange; i++) {
				var dateToAdd = start.clone().add(i, 'days');
				dateArray.push(dateToAdd);
			}
			$('#cal-data').text(formattedDate_start + ' - ' + formattedDate_end);
		
			$('#start_time').val(start.format("hh:mm A"));
			$('#end_time').val(end.format("hh:mm A"));
		
			$('#eventTitle').val('');
		
			$('#saveEvent').off('click').on('click', function() {
				var title = $('#eventTitle').val();
				if (title) {
					var startTime = $('#start_time').val();
					var endTime = $('#end_time').val();
			
					// Check if the start and end times are the same for a single day
					if (daysInRange === 1 && startTime === endTime) {
						alert("Start and end times are the same for a single day. Please select a time range.");
					} else {
						// Loop through the dateArray and add the event for each date
						dateArray.forEach(function(dateToAdd) {
							var startDate = moment(dateToAdd.format('YYYY-MM-DD') + ' ' + startTime, 'YYYY-MM-DD hh:mm A');
							var endDate = moment(dateToAdd.format('YYYY-MM-DD') + ' ' + endTime, 'YYYY-MM-DD hh:mm A');
			
							var formattedStart = startDate.format("Y-MM-DD HH:mm:ss");
							var formattedEnd = endDate.format("Y-MM-DD HH:mm:ss");
							var action = "add_data";
			
							$.ajax({
								url: ajaxUrl,
								type: "POST",
								data: { action: action, title: title, start: formattedStart, end: formattedEnd },
								success: function(response) {
									calendar.fullCalendar('refetchEvents');
									// If you want to hide the popup after adding the events, uncomment the line below
									$('#customPopup').hide();
								}
							});
						});
					}
				} else {
					alert("Please enter a title for the event.");
				}
			});			
		},
	 
		 
		 eventResize:function(event)
		 {
		  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
		  var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
		  var title = event.title;
		  var action = "update_data";
		  var id = event.id;
		  $.ajax({
		   url:ajaxUrl,
		   type:"POST",
		   data:{action:action,title:title, start:start, end:end, id:id},
		   success:function(){
			calendar.fullCalendar('refetchEvents');
			alert('Event Update');
		   }
		  })
		 },
	 
		 eventDrop:function(event)
		 {
		  var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD HH:mm:ss");
		  var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD HH:mm:ss");
		  var title = event.title;
		  var action ="update_data";
		  var id = event.id;
		  $.ajax({
		   url:ajaxUrl,
		   type:"POST",
		   data:{action:action,title:title, start:start, end:end, id:id},
		   success:function(response)
		   {
			calendar.fullCalendar('refetchEvents');
			alert("Event Updated");
		   }
		  });
		 },
	 
		 eventClick:function(event)
		 {
		  if(confirm("Are you sure you want to remove it?"))
		  {
		   var id = event.id;
		   var action = 'delete_data';
		   $.ajax({
			url: ajaxUrl,
			type:"POST",
			data:{action:action,id:id},
			success:function()
			{
			 calendar.fullCalendar('refetchEvents');
			 alert("Event Removed");
			}
		   })
		  }
		 },
		 eventRender: function(event, element, view) {
			var start = event.start.format('h:mm A');
			var end = event.end ? moment(event.end) : null;
		
			if (end === null) {
				var endDate = event.start.clone().set({ hour: 23, minute: 59 });
				end = moment(endDate);
				var duration = end.diff(event.start, 'minutes');
				if (view.type === 'agendaWeek' || view.type === 'agendaDay') {
					element.find('.fc-content').css({
						color: 'white',
					});
		
					element.css('height', duration + 'px');
				}
			}
			var formattedTitle = (start === end.format('h:mm A')) ? start : start + ' - ' + end.format('h:mm A');
				element.find('.fc-time').empty().text(formattedTitle);
				if (view.type === 'month') {
					element.find('.fc-content').css({
						display: 'flex',
						"flex-direction": 'column',
						color: 'white'
					});
				
			}
		
			if (view.type !== 'month') {
				element.find('.fc-time').attr('data-start', '');
				element.find('.fc-content').css({
					color: 'white',
				});
			}
		}
		
		
		
		
		});
		$('#closePopup').click(function() {
			 $('#customPopup').hide(); 
		});
		
	 });
	
})( jQuery );
