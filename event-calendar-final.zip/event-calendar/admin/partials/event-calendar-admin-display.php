<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://hztech.biz/
 * @since      1.0.0
 *
 * @package    Event_Calendar
 * @subpackage Event_Calendar/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
 
  <div class="wrap">
    <h2>Admin Calendar</h2>
    <br />
    <p>Add this shortcode to use the Calendar "[event_calendar]"</p>
  <div class="container">
   <div id="calendar"></div>
  </div>
 </div>

<!-- Popup box -->
   <div id="customPopup" class="popup  popup-cal">
        <div class="popup-content">
            <span class="close" id="closePopup">&times;</span>
            <h6>Date: <span id="cal-data"><span></h6>
            <input type="hidden" id="date-hid" value="">
            <div class="form-group" style="display:flex;flex-direction:column;">
              <label>Start Time</label>
              <input type="text" id="start_time" value="" style="text-transform: uppercase;">
            </div>
            <div class="form-group" style="display:flex;flex-direction:column;">
              <label>End Time</label>
              <input type="text" id="end_time" value="" style="text-transform: uppercase;">
            </div>
            <label>Enter Link</label>
            <input type="text" id="eventTitle" placeholder="Enter here...">
            <button id="saveEvent">Save</button>
        </div>
  </div>
  

