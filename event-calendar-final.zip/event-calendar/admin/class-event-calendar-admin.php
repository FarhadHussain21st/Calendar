<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://hztech.biz/
 * @since      1.0.0
 *
 * @package    Event_Calendar
 * @subpackage Event_Calendar/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Event_Calendar
 * @subpackage Event_Calendar/admin
 * @author     Hztech <info@hztech.biz>
 */
class Event_Calendar_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Calendar_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Calendar_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name.'-calendar-css','https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css', array(), rand(0,100), 'all' );
		wp_enqueue_style( $this->plugin_name.'-bootstrap-css','https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.css', array(), rand(0,100), 'all' );
		wp_enqueue_style( $this->plugin_name.'-calendar-css','https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.3.5/jquery.timepicker.min.css', array(), rand(0,100), 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/event-calendar-admin.css', array(), rand(0,100), 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Calendar_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Calendar_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
        wp_localize_script('event-calendar-scripts', 'web_url', array(
            'ajaxurl' => admin_url('admin-ajax.php')
        ));
		
		wp_enqueue_script( $this->plugin_name.'-jquery', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js', array(  ), rand(0,100), false );
		wp_enqueue_script( $this->plugin_name.'-jquery-ui', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js', array(  ), rand(0,100), false );
		// wp_enqueue_script( $this->plugin_name.'-jquery-date', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.3.5/jquery.timepicker.min.js', array(  ), rand(0,100), false );
		wp_enqueue_script( $this->plugin_name.'-moment-js', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js', array(  ), rand(0,100), false );
		wp_enqueue_script( $this->plugin_name.'-fullcanledar', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js', array(  ), rand(0,100), false );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/event-calendar-admin.js', array( 'jquery' ), rand(0,100), false );
		
	}

	public function admin_menu_register(){
        add_menu_page(
            'Event Calendar',
            'Event Calendar',
            'manage_options',
            'event-calendar',
            [$this,'displayEventCalendar'],
            '',
            20
        );
    }

	public function register_events_calendar_post_type() {
        $args = array(
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => false, 
            'show_in_menu' => false,
            'query_var' => true,
            'rewrite' => array('slug' => 'events-calendar'),
            'capability_type' => 'post',
            'hierarchical' => false,
            'supports' => array('title', 'editor', 'custom-fields'),
        );
    
        register_post_type('events_calendar', $args);
    }

    public function displayEventCalendar() {
        include( plugin_dir_path(__FILE__) . 'partials/event-calendar-admin-display.php');
    }

	// Data Functions

	public function load_data() {
		$data = array();
		$args = array(
			'post_type' => 'events_calendar',
			'posts_per_page' => -1,
		);
		$events_query = new WP_Query($args);
		if ($events_query->have_posts()) {
			while ($events_query->have_posts()) {
				$events_query->the_post();
				$data[] = array(
					'id' => get_the_ID(),
					'title' => get_post_meta(get_the_ID(), 'link_event', true),
					'start' => get_post_meta(get_the_ID(), 'start_event', true),
					'end' => get_post_meta(get_the_ID(), 'end_event', true),
				);
			}
		}
		wp_send_json($data);
	}

	public function add_data() {
		$event_title = sanitize_text_field($_POST['title']);
		$event_start = sanitize_text_field($_POST['start']);
		$event_end = sanitize_text_field($_POST['end']);
		$link = sanitize_text_field($_POST['title']);
		$event_id = wp_insert_post(array(
			'post_title' => $event_title, 
			'post_type' => 'events_calendar',
			'post_status' => 'publish',
		));

		update_post_meta($event_id, 'start_event', $event_start);
		update_post_meta($event_id, 'end_event', $event_end);
		update_post_meta($event_id, 'link_event', $link);

		
		$event_data = array(
			'id' => $event_id,
			'title' => $link,
			'start' => $event_start,
			'end' => $event_end,
		);
		
		wp_send_json($event_data);
	
	}

	public function update_data() {
        
		$event_id = intval($_POST['id']);
		$event_title = sanitize_text_field($_POST['title']);
		$event_start = sanitize_text_field($_POST['start']);
		$event_end = sanitize_text_field($_POST['end']);
		$link = sanitize_text_field($_POST['title']);
		
		wp_update_post(array(
			'ID' => $event_id,
			'post_title' => $event_title,
		));
		
		update_post_meta($event_id, 'start_event', $event_start);
		update_post_meta($event_id, 'end_event', $event_end);
		update_post_meta($event_id, 'link_event', $link);

		
		$updated_event_title = get_the_title($event_id);

		
		$updated_event_data = array(
			'id' => $event_id,
			'title' => $link, 
			'start' => $event_start,
			'end' => $event_end,
		);
		wp_send_json($updated_event_data);
	
	}

	public function delete_data() {
        $event_id = intval($_POST['id']);
        wp_delete_post($event_id, true);
        wp_send_json(array('message' => 'Event deleted successfully'));   
    }

}
