<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://hztech.biz/
 * @since      1.0.0
 *
 * @package    Event_Calendar
 * @subpackage Event_Calendar/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Event_Calendar
 * @subpackage Event_Calendar/public
 * @author     Hztech <info@hztech.biz>
 */
class Event_Calendar_Public
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Calendar_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Calendar_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style($this->plugin_name . '-calendar-css', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css', array(), rand(0, 100), 'all');
		wp_enqueue_style($this->plugin_name . '-bootstrap-css', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.css', array(), rand(0, 100), 'all');
		wp_enqueue_style($this->plugin_name . '-public-css', plugin_dir_url(__FILE__) . 'css/event-calendar-public.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Calendar_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Calendar_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		// Enqueue jQuery (if it's not already enqueued)
		if (!wp_script_is('jquery', 'enqueued')) {
			wp_enqueue_script('jquery');
		}

		wp_enqueue_script($this->plugin_name . '-moment-js', 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js', array('jquery'), '2.18.1', true);
		wp_enqueue_script($this->plugin_name . '-fullCalendar-display', 'https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js', array('jquery', $this->plugin_name . '-moment-js'), '3.4.0', true);

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/event-calendar-public.js', array('jquery', $this->plugin_name . '-moment-js', $this->plugin_name . '-fullCalendar-display'), '1.0', true);

		wp_localize_script($this->plugin_name, 'web_url', array(
			'ajaxurl' => admin_url('admin-ajax.php')
		));
	}

	public function do_shortcode()
	{
		add_shortcode('event_calendar', [$this, 'event_calendar_shortcode']);
	}

	public function event_calendar_shortcode()
	{
		ob_start();
		include(plugin_dir_path(__FILE__) . 'partials/event-calendar-public-display.php');
		return ob_get_clean();
	}
	public function load_data_front()
	{
		$data = array();
		$args = array(
			'post_type' => 'events_calendar',
			'posts_per_page' => -1,
		);
		$events_query = new WP_Query($args);
		if ($events_query->have_posts()) {
			while ($events_query->have_posts()) {
				$events_query->the_post();
				$data[] = array(
					'id' => get_the_ID(),
					'title' => get_post_meta(get_the_ID(), 'link_event', true),
					'start' => get_post_meta(get_the_ID(), 'start_event', true),
					'end' => get_post_meta(get_the_ID(), 'end_event', true),
				);
			}
		}
		wp_send_json($data);
	}
}
