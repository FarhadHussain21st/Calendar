(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	jQuery.noConflict();
	jQuery(document).ready(function($) {
        var ajaxUrl = web_url.ajaxurl;
        var calendar = $('#calendar_front').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,agendaWeek,agendaDay'
            },
            events: ajaxUrl + '?action=load_data_front',
            selectable: false,
            selectHelper: false,
            editable: false,
            eventRender: function(event, element, view) {
                var title = event.title;
                var start = event.start.format('h:mm A');
                var end = event.end ? moment(event.end) : null;
    
                if (end === null) {
                    var endDate = event.start.clone().set({ hour: 23, minute: 59 });
                    end = moment(endDate);
    
                    var duration = end.diff(event.start, 'minutes');
                    console.log(duration);
    
                    if (view.type === 'agendaWeek' || view.type === 'agendaDay') {
                        element.css('height', duration + 'px');
                    }
                }
    
                var formattedTitle = (start === end.format('h:mm A')) ? start : start + ' - ' + end.format('h:mm A');
                element.find('.fc-time').empty().text(formattedTitle);
    
                var link = $('<a>')
                    .attr('href', 'http://' + title) // Use the event URL as the link URL
                    .attr('target', '_blank')
                    .text(title)
                    .css('color', 'white');

                    if(view.type == "month"){
                        element.find('.fc-content').css({
                            display: 'flex',
                            'flex-direction': 'column',
                            color: 'white'
                        });
                    }
    
                element.find('.fc-time').css('color', 'white');
                element.find('.fc-title').html(link);
            }
        });
    });
    
        

})( jQuery );


